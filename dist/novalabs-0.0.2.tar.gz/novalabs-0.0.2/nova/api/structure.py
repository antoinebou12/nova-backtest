class Structure:
    # Entity mapping
    bots_map = {}
