# python-nova
Built in client interaction with the Centralized Exchange Platform API

### Code
See tutorial [here](https://medium.com/@pietrassyk/building-a-custom-pip-library-for-python-fe618034d54a) for creating a python lib on pip.


## To update the librairie version 

run :

python3 setup.py sdist bdist_wheel
